/*
This program has an integer overflow vulnerability.
 */

#include "add.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int a = 0;
  int b = 0;
  
  if (argc != 3)
    {
      printf("Usage: add a b\n");
      return 0;
    }

  a = atoi(argv[1]);
  b = atoi(argv[2]);

  printf("%d + %d = %d\n", a, b, add(a, b));
}
