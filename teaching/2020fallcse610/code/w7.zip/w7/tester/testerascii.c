#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>

char buf[0x1000] = {0};

char *asciicpy(char *dest, const char *src)
{
	unsigned i;
	for (i = 0; src[i] > 0 && src[i] < 127; ++i)
		dest[i] = src[i];

	return dest;
}

int main()
{
	void * page = 0;
	page = mmap(0, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, 0, 0);
	
	if (!page)
	{
		puts("Fail to mmap.\n");
		exit(0);
	}

	read(0, buf, 0x1000);
	asciicpy(page, buf);
	((void(*)())page)();
}

