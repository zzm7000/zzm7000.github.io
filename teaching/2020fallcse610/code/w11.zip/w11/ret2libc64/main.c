/*
This program has a buffer overflow vulnerability.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h> 

FILE* fp = 0;

int vulfoo()
{
	char buf[4];
	
	fp = fopen("exploit", "r");
	if (!fp)
		exit(0);
  
	fread(buf, 1, 1000, fp);
	
	return 0;
}

int main(int argc, char *argv[])
{
	vulfoo();
	return 0;
}
