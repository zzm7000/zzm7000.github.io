/*
This program has a format string vulnerability.
 */

#include <stdio.h>

char *p1 = "This is secret1!!";

char *p2 = "This is secret2!!";
	
int vulfoo()
{
	char tmpbuf[120];
	gets(tmpbuf);
   
	printf(tmpbuf);
	return 0;
}

int main() {
	printf("Secret are at %p and %p. Can you read them?\n", p1, p2);
	return vulfoo();
}
