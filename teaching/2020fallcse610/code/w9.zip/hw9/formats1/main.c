/*
This program has a format string vulnerability.
 */

#include <stdio.h>

int vulfoo()
{
	char s[20];
   
	printf("What is your input?\n");
	gets(s);
   
	printf(s);
	return 0;
}

int main() {
	return vulfoo();
}
