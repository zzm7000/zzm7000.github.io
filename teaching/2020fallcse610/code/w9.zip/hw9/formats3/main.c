/*
This program has a format string vulnerability.
 */

#include <stdio.h>
	
int vulfoo()
{
	char buf1[100];
	char buf2[100];
		
	fgets(buf2, 99, stdin);
	sprintf(buf1, buf2);
	return 0;
}

int main() {
	return vulfoo();
}
