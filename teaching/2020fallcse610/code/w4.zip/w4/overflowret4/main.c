/*
This program has a buffer overflow vulnerability.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int vulfoo()
{
  char buf[40];

  gets(buf);
  return 0;}

int main(int argc, char *argv[])
{
  vulfoo();
  printf("I pity the fool!\n");  
}
