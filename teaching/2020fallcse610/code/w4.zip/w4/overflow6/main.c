/*
This program has a buffer overflow vulnerability.
The attacker can only overwrite Saved EBP, but not more. So, there is no enough space to put the shellcode. Use the env to store shellcode.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int vulfoo(char *p)
{
	char buf[4];

	memcpy(buf, p, 12);

	return 0;
}

int main(int argc, char *argv[])
{
	if (argc != 2)
		return 0;
		
	vulfoo(argv[1]);
}
