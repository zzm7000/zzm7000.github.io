/*
This program has a buffer overflow vulnerability.
Use buffer overflow to printout "Knowlege is power. France is bacon."
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int f1()
{
  printf("Knowledge ");
}

int f2()
{
  printf("is ");
}

void f3()
{
  printf("power. ");
}

void f4()
{
  printf("France ");
}

void f5()
{
  printf("bacon.\n");
  exit(0);
}

int vulfoo()
{
  char buf[6];

  gets(buf);
  return 0;
}

int main(int argc, char *argv[])
{
  printf("Function addresses:\nf1: %p\nf2: %p\nf3: %p\nf4: %p\nf5: %p\n", f1, f2, f3, f4, f5);
  vulfoo();
  printf("I pity the fool!\n");  
}
