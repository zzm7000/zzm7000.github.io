#define _GNU_SOURCE 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <seccomp.h>

int main(int argc, char *argv[])
{
#ifdef MYSANDBOX
	scmp_filter_ctx ctx;
	ctx = seccomp_init(SCMP_ACT_ALLOW);
	seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execve), 0);
	seccomp_load(ctx);
#endif
	
	execl("/bin/cat", "cat", "./secret", (char*)0);		
	return 0; 	 		
}
