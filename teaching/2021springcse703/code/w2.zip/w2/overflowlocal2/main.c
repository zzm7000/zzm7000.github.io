/*
This program has a buffer overflow vulnerability stack.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *secret = "This is a secret";

int vulfoo(int i, char* p)
{
  int j = i;
  char buf[6];

  strcpy(buf, p);

  if (j == 0x12345678)
    printf("%s\n", secret);
  else
    printf("I pity the fool!\n");

  return 0;
}

int main(int argc, char *argv[])
{
  vulfoo(argc, argv[1]);
}
