/*
This program demonstrates stack using factorial.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int fact(int n)
{
  printf("---In fact(%d)\n", n);
  printf("&n is %p\n", &n);

  if (n <= 1)
    return 1;

  return fact(n-1) * n;
}

int main(int argc, char *argv[])
{
  if (argc != 2)
  {
    printf("Usage: fact integer\n");
    return 0;
  }

  printf("The factorial of %d is %d\n.", atoi(argv[1]), fact(atoi(argv[1])));
}
