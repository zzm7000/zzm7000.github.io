#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>


int main(int argc, char *argv[])
{
   FILE *fp = NULL;
   char buffer[100] = {0};

   // get ruid and euid
   uid_t uid = getuid();
   struct passwd *pw = getpwuid(uid);
   if (pw)
   {
	printf("UID: %d, USER: %s.\n", uid, pw->pw_name);
   }

   uid_t euid = geteuid();
   pw = getpwuid(euid);
   if (pw)
   {
	printf("EUID: %d, EUSER: %s.\n", euid, pw->pw_name);
   }
  
   // open the file
   fp = fopen("secret.txt", "r");
   if (fp == NULL)
   {
	printf("Can't read the secret!\n");
	return(1);
   }

   fread(buffer, 99, 1, fp);
   printf("%s\n", buffer);
   fclose(fp);
   
   return(0);
}
