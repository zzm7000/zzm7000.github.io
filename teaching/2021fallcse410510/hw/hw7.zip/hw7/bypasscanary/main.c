/*
This program has a buffer overflow vulnerability.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h> 
#include <sys/wait.h>

char g_buffer[200] = {0};
int g_read = 0;

int vulfoo()
{
	char buf[40];
	FILE *fp;

	while (1)
	{
		fp = fopen("exploit", "r");
		if (fp)
			break;
	}
	
	usleep(250 * 1000);
	g_read = 0;
	memset(g_buffer, 0, 200);
	g_read = fread(g_buffer, 1, 70, fp);
	printf("Child reads %d bytes. Guessed canary is %x.\n", g_read, *((int*)(&g_buffer[40])));
	
	memcpy(buf, g_buffer, g_read);
	
	fclose(fp);
	remove("exploit");
	return 0;
}

int main(int argc, char *argv[])
{
	while(1)
	{
		if (fork() == 0)
		{
			//child
			printf("Child pid: %d\n", getpid());
			vulfoo();
			printf("I pity the fool!\n");
			exit(0);
		}
		else
		{
			//parent
			int status;
			printf("Parent pid: %d\n", getpid());
			waitpid(-1, &status, 0);
		}
	}  
}
