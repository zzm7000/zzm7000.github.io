#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/*This program has a buffer overflow. There is no canary. The goal is to call printsecret when ASLR is enabled.*/

int printsecret()
{
	printf("This is the secret...\n");
		
	return 0;
}

int vulfoo()
{
	printf("vulfoo is at %p \n", vulfoo);
	char buf[8];
	read(0, buf, 30);
		
	return 0;	
}

int main(int argc, char *argv[])
{
	vulfoo();			
	return 0; 	 		
}
