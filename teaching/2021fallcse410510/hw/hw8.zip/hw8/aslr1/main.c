#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int k = 50;
int l;
char *p = "hello world";

int add(int a, int b)
{
	int i = 10;
	i = a + b;
	printf("The address of i is %p\n", &i);
		
	return i;
}

int sub(int d, int c)
{
	int j = 20;
	j = d - c;
	printf("The address of j is %p\n", &j);
		
	return j;	
}

int compute(int a, int b, int c)
{
	return sub(add(a, b), c) * k;
}

int main(int argc, char *argv[])
{
	printf("===== Libc function addresses =====\n");
	printf("The address of printf is %p\n", printf);
	printf("The address of memcpy is %p\n", memcpy);
	printf("The distance between printf and memcpy is %x\n", (int)printf - (int)memcpy);	
	printf("The address of system is %p\n", system);
	printf("The distance between printf and system is %x\n", (int)printf - (int)system);			
		
	printf("===== Module function addresses =====\n");		
	printf("The address of main is %p\n", main);   
	printf("The address of add is %p\n", add); 
	printf("The distance between main and add is %x\n", (int)main - (int)add);
	printf("The address of sub is %p\n", sub);
	printf("The distance between main and sub is %x\n", (int)main - (int)sub);	
	printf("The address of compute is %p\n", compute);
	printf("The distance between main and compute is %x\n", (int)main - (int)compute);	
	printf("The distance between main and printf is %x\n", (int)main - (int)printf);	
	printf("The distance between main and memcpy is %x\n", (int)main - (int)memcpy);	
		
	printf("===== Global initialized variable addresses =====\n");		
	printf("The address of k is %p\n", &k);
	printf("The address of p is %p\n", p);
	printf("The distance between k and p is %x\n", (int)&k - (int)p);	
	printf("The distance between k and main is %x\n", (int)&k - (int)main);	
	printf("The distance between k and memcpy is %x\n", (int)&k - (int)memcpy);
		
	printf("===== Global uninitialized variable addresses =====\n");		
	printf("The address of l is %p\n", &l);
	printf("The distance between k and l is %x\n", (int)&k - (int)l);		
			
	printf("===== Local variable addresses =====\n");			
	return compute(9, 6, 4); 	 		
}
