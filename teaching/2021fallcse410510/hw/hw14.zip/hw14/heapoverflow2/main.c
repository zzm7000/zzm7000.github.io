/* 
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void secret()
{
	printf("The secret is bla bla...\n");
}

void fly()
{
	printf("Flying ...\n");
}

typedef struct airplane
{
	void (*pfun)();
	char name[20];
} airplane;

typedef struct car
{
        int volume;
        char name[20];
} car;

int main()
{
  printf("fly() at %p; secret() at %u\n", fly, (unsigned int)secret);
    
    struct airplane *p = malloc(sizeof(airplane));
    printf("Airplane is at %p\n", p);
    p->pfun = fly;
    p->pfun();
    free(p);
    
    p = malloc(sizeof(car));
    printf("Car is at %p\n", p);

    int volume;
    printf("What is the volume of the car?\n");
    scanf("%u", &volume);
    ((struct car *)(p))->volume = volume;
    
    p->pfun();
    free(p);
    return 0;
}
