/* compiled with: gcc -o print_frees print_frees.c */
/* Only do this for 32 bit */
/* The result is a single link */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define LEN 5

void print_inuse_chunk(unsigned int * ptr)
{
        printf("[ prev - 0x%08x ][ size - 0x%08x ][ data buffer (0x%08x) ----> ... ] - Chunk 0x%08x - In use\n", \
                *(ptr-2),
                *(ptr-1),
                (unsigned int)ptr,
                (unsigned int)(ptr-2));
}
                
void print_freed_chunk(unsigned int * ptr)
{
        printf("[ prev - 0x%08x ][ size - 0x%08x ][ fd - 0x%08x ][ bk - 0x%08x ] - Chunk 0x%08x - Freed\n", \
                *(ptr-2),
                *(ptr-1),
                *ptr,
                *(ptr+1),
                (unsigned int)(ptr-2));
}

int main()
{
    unsigned int * ptr[LEN];
    unsigned int lengths[] = {32, 32, 32, 32, 32};
    int i;

    printf("mallocing...\n");
    for(i = 0; i < LEN; i++)
        ptr[i] = malloc(lengths[i]);
    
    for(i = 0; i < LEN; i++)
        print_inuse_chunk(ptr[i]);
   
    printf("\nfreeing all chunks...\n");
    for(i = 0; i < LEN; i++)
        free(ptr[i]);

    for(i = 0; i < LEN; i++)
        print_freed_chunk(ptr[i]);
    
    return 0;
}
