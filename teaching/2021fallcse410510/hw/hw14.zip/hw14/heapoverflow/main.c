/* 
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void secret()
{
	printf("The secret is bla bla...\n");
}

void fly()
{
	printf("Flying ...\n");
}

typedef struct airplane
{
	void (*pfun)();
	char name[20];
} airplane;

int main()
{
    printf("fly() at %p; secret() at %p\n", fly, secret);
    
    struct airplane *p1 = malloc(sizeof(airplane));
    printf("Airplane 1 is at %p\n", p1);
    printf("Airplane 1's name is at %p\n", p1->name);
    
    struct airplane *p2 = malloc(sizeof(airplane));
    printf("Airplane 2 is at %p\n", p2);
    
    p1->pfun = fly;
    p2->pfun = fly;    
    
    fgets(p2->name, 10, stdin);
    fgets(p1->name, 50, stdin);    
    
    p1->pfun();
    p2->pfun();
       
    free(p1);
    free(p2);
    return 0;
}
