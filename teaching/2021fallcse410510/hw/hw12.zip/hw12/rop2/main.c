/*
This program has a buffer overflow vulnerability.

A format string vulnerabilty to overwirte the RET.

Then, use xchg esp, eax to switch to new stack, which you have enough space for ROP chain.
 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h> 

FILE* fp = 0;
int a = 0;

int vulfoo(int i)
{
	char buf[200];
	
	fp = fopen("exploit", "r");
	if (!fp)
	{
		perror("fopen");
		exit(0);		
	}
  
	fread(buf, 1, 190, fp);
	
	// Move the first 4 bytes to RET 
        *((unsigned int *)(&i) - 1) = *((unsigned int *)buf);
        a = *((unsigned int *)buf + 1);
        
        // Move the second 4 bytes to eax
        asm ( "movl %0, %%eax"
        :
        :"r"(a)
        );
}

int main(int argc, char *argv[])
{
	vulfoo(1);
	return 0;
}
