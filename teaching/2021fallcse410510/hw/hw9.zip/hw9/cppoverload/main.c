/*
This program 
 */

#include <stdio.h>

double average(int i, int j, int k) {
   return (i + j + k) / 3;}
   
double average(int i, int j, int k, int l) {
   return (i + j + k + l) / 4;}

int main() {
   printf("Average of 2, 3, 4, 5 = %f\n", average(2, 3, 4, 5));
   printf("Average of 5, 10, 15 = %f\n", average(5, 10, 15));
}
