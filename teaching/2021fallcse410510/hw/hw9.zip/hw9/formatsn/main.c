/*
This program has 
 */

#include <stdio.h>

int foo()
{
	int a = 0;
	int b = 0;
	printf("a is %d; b is %d\n", a, b);
	printf("[Changing a and b..]%n12345%n\n", &a, &b);
	printf("a is %d; b is %d\n", a, b);
	
	printf("[Changing a and b..]%020d %n%n\n", 50, &a, &b);
	printf("a is %d; b is %d\n", a, b);
	
	printf("[Changing a and b..]floats: %010.2f%n\n", 3.1416, &a);
	printf("a is %d.\n", a);
		   
	return 0;
}

int main() {
	return foo();
}
