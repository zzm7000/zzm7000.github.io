/*
This program has a format string vulnerability.
 */

#include <stdio.h>

FILE* fp;
	
void printsecret()
{
	printf("This is a secret!");
	exit(0);
}

int vulfoo()
{
	char tmpbuf[512];
	fread(tmpbuf, 510, 1, fp);
   
	printf(tmpbuf);
	return 0;
}

int main() {
	fp = fopen("./exploit64", "r");
	
	vulfoo();
	
	fclose(fp);
	return 0;
}
