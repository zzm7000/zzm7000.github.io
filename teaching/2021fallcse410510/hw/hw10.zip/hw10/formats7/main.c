/*
This program has a format string vulnerability.
 */

#include <stdio.h>

int auth = 0;
int auth1 = 0;
int auth2 = 0;
	
void printsecret()
{
	printf("This is a secret!");
	exit(0);
}

int vulfoo()
{
	char tmpbuf[512];
	fgets(tmpbuf, 510, stdin);
   
	printf(tmpbuf);
	return 0;
}

int main() {
	vulfoo();

	printf("auth = %d, auth1 = %d\n", auth, auth1);
	
	if (auth == 40 && auth1 == 75 && auth2 == 135)
		printsecret();
}
