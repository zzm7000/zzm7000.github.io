/*
This program has a buffer overflow vulnerability.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int printsecret(int i, int j)
{
  if (i == 0x12345678 && j == 0xdeadbeef) 
    printf("Congratulations! You made it!\n");
  else
    printf("I pity the fool!\n");  

  exit(0);}

int vulfoo()
{
  char buf[6];

  gets(buf);
  return 0;}

int main(int argc, char *argv[])
{
  printf("The addr of printsecret is %p\n", printsecret);
  vulfoo();
  printf("I pity the fool!\n");  
}
