/*
This program demonstrates global variables and local variables.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef FAST
#define FASTCALL __attribute__ ((fastcall))
#else
#define FASTCALL
#endif

char g_i[] = "I am an initialized global variable\n";
char* g_u;

int __attribute__ ((fastcall)) func(int p)
{
  int l_i = 10;
  int l_u;

  printf("l_i in func() is at %p\n", &l_i);
  printf("l_u in func() is at %p\n", &l_u);  
  printf("p in func() is at %p\n", &p);  

  return 0;
}

int main(int argc, char *argv[])
{
  int l_i = 10;
  int l_u;

  printf("g_i is at %p\n", &g_i);
  printf("g_u is at %p\n", &g_u);  

  printf("l_i in main() is at %p\n", &l_i);
  printf("l_u in main() is at %p\n", &l_u);   

  func(10);
}
