/*
This program demonstrates stack using factorial.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int fp(int a, int b, int c, int d, int e)
{
  return a + b + c + d + e;
}

int main(int argc, char *argv[])
{
  fp(1, 2, 3, 4, 5);
}
