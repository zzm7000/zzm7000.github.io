#include <stdio.h>
#include <stdlib.h>

int main()
{
	getchar();
	return 0;
}
