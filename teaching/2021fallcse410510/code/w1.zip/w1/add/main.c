/*
This program has an integer overflow vulnerability.
 */

#include "add.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define USAGE "Usage: add a b\n"

int main(int argc, char *argv[])
{
  int a = 0;
  int b = 0;
  
  if (argc != 3)
    {
      printf(USAGE);
      return 0;
    }

  a = atoi(argv[1]);
  b = atoi(argv[2]);

  printf("%d + %d = %d\n", a, b, add(a, b));
}
