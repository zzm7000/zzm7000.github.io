#ifndef ADD_H
#define ADD_H

int add(int, int);

#endif
