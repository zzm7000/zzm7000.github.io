/*
This program has a buffer overflow vulnerability.
The attacker can only overwrite RET, but not more. So, there is no enough space to put the shellcode. Use the env to store shellcode.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int vulfoo()
{
  char buf[4];

  fgets(buf, 18, stdin);

  return 0;
}

int main(int argc, char *argv[])
{
  vulfoo();
}
