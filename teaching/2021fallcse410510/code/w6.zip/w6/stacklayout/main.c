/*
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[], char *envp[])
{
	printf("argc is at %p; its value is %d\n", &argc, argc);
	printf("argv[0] is at %p; its value is %s\n", &argv[0], argv[0]);
	printf("argv[1] is at %p; its value is %s\n", &argv[1], argv[1]);
	printf("argv[2] is at %p; its value is %s\n", &argv[2], argv[2]);
	printf("envp[0] is at %p; its value is %s\n", &envp[0], envp[0]);
	printf("envp[1] is at %p; its value is %s\n", &envp[1], envp[1]);
	printf("envp[2] is at %p; its value is %s\n", &envp[2], envp[2]);	
	
	return 0;
}
